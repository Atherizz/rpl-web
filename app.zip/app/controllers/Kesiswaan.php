<?php
class Kesiswaan extends Controller
{

    public function index()
    {
        $this->view('template/header');

    }
}
