<?php 

class Akademik extends Controller {

public function index() {

    $this->view('template/header');
    // $this->view('template/footer');
}

}


