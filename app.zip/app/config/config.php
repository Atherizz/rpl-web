<?php

define('BASEURL', 'http://localhost/rpl-web/public');

// DB
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'sdn');
